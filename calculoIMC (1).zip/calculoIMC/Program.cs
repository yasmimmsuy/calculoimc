﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<Pessoa> pessoas = new List<Pessoa>();

        Console.WriteLine("Calculadora de IMC");
        Console.WriteLine("==================");

        while (true)
        {
            Console.Write("\nNome (ou 'sair' para encerrar): ");
            string nome = Console.ReadLine();

            if (nome.ToLower() == "sair") break;

            Console.Write("Sexo (M/F): ");
            char sexo = char.ToUpper(Console.ReadLine()[0]);

            Console.Write("Peso (kg): ");
            double peso = double.Parse(Console.ReadLine());

            Console.Write("Altura (m): "); 
            double altura = double.Parse(Console.ReadLine());

            Pessoa pessoa = new Pessoa(nome, sexo, peso, altura);
            pessoas.Add(pessoa);

            Console.WriteLine("\nDados registrados:");
            Console.WriteLine(pessoa);
        }

        Console.WriteLine("\nRelatório Final:");
        Console.WriteLine("==================");
        foreach (var pessoa in pessoas)
        {
            Console.WriteLine(pessoa);
            Console.WriteLine();
        }
    }
}

class Pessoa
{
    public string Nome { get; set; }
    public char Sexo { get; set; }
    public double Peso { get; set; }
    public double Altura { get; set; }
    public double IMC { get; private set; }
    public string Condicao { get; private set; }
    public string Recomendacao { get; private set; }

    public Pessoa(string nome, char sexo, double peso, double altura)
    {
        Nome = nome;
        Sexo = sexo;
        Peso = peso;
        Altura = altura;
        CalcularIMC();
        DeterminarCondicao();
        GerarRecomendacao();
    }

    private void CalcularIMC()
    {
        IMC = Peso / (Altura * Altura);
    }

    private void DeterminarCondicao()
    {
        if (Sexo == 'F')
        {
            if (IMC < 19.1) Condicao = "abaixo do peso";
            else if (IMC <= 25.8) Condicao = "no peso normal";
            else if (IMC <= 27.3) Condicao = "marginalmente acima do peso";
            else if (IMC <= 32.3) Condicao = "acima do peso ideal";
            else Condicao = "obeso";
        }
        else
        {
            if (IMC < 20.7) Condicao = "abaixo do peso";
            else if (IMC <= 26.4) Condicao = "no peso normal";
            else if (IMC <= 27.8) Condicao = "marginalmente acima do peso";
            else if (IMC <= 31.1) Condicao = "acima do peso ideal";
            else Condicao = "obeso";
        }
    }

    private void GerarRecomendacao()
    {
        double imcDesejado = (Sexo == 'F') ? 22.45 : 23.55;
        double pesoDesejado = imcDesejado * (Altura * Altura);
        double diferenca = pesoDesejado - Peso;

        if (Condicao == "no peso normal")
        {
            Recomendacao = "Mantenha seu peso atual.";
        }
        else if (diferenca > 0)
        {
            Recomendacao = $"Você precisa ganhar {Math.Abs(diferenca):F1} kg para atingir o peso normal.";
        }
        else
        {
            Recomendacao = $"Você precisa perder {Math.Abs(diferenca):F1} kg para atingir o peso normal.";
        }
    }

    public override string ToString()

    {
        return $"Nome: {Nome}\n" +
               $"Sexo: {(Sexo == 'F' ? "Feminino" : "Masculino")}\n" +
               $"Peso: {Peso:F1} kg\n" +
               $"Altura: {Altura:F2} m\n" +
               $"IMC: {IMC:F1}\n" +
               $"Condição: {Condicao}\n" +
               $"Recomendação: {Recomendacao}";
    }
}